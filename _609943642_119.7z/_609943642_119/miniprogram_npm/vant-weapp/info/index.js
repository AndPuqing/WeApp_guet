(0, require("../common/component").VantComponent)({
    props: {
        dot: Boolean,
        info: null,
        customStyle: String
    }
});
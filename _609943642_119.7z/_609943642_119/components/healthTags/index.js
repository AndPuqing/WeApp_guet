Component({
    properties: {
        health: {
            type: Object
        }
    },
    data: {},
    ready: function() {},
    methods: {}
});
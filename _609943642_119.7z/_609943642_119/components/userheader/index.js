Component({
    properties: {
        url: {
            type: String,
            value: ""
        },
        size: {
            type: Number,
            value: 100
        }
    },
    data: {},
    methods: {}
});
Component({
    properties: {
        title: String,
        desc: String,
        time: String
    },
    data: {},
    methods: {}
});
Component({
    properties: {
        title: String,
        subtitle: String,
        minititle: String
    },
    data: {},
    methods: {}
});